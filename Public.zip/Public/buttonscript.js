// -----JS CODE-----

//add all the poems here:
//@input SceneObject poem1;
//@input SceneObject poem2;
//@input SceneObject poem3;
// //@input SceneObject button1;

//starts from the first poem:
var currentPoem = 1;

//call this from behavior script (Call Object API, Call Type: Call Function, name:enableEnablePoem )
global.enableEnablePoem  = function()

{
    print(currentPoem);
    
    switch(currentPoem)
    {
        case 1:
        script.poem1.enabled = true;
//        script.poem2.enabled = false;  
 //       script.showlantern.enabled = false;
        break;
        
        case 2:
        script.poem1.enabled = false;        
        script.poem2.enabled = true;
 //       script.showlantern.enabled = false;
        break;
        
        case 3:
        script.poem2.enabled = false;        
        script.poem3.enabled = true;
  //      script.button1.enabled = false;
      //  script.button2.enabled = true;
 //       script.showlantern.enabled = false;
        break;
        
        case 4:
        script.poem3.enabled = false;
        global.scBehaviorSystem.sendCustomTrigger("showlantern");
   //     script.button2.enabled = true;
 //       script.showlantern.enabled = true;
        break;
 
    }
    
    //increase currentPoem to activate the next in the next response
    currentPoem++;
    
    //to make the poems loop even when you reach the end, reset the currentPoem var when you reach the end:
 //   if(currentPoem>4)
   // {
     //   currentPoem = 1;
   // }
    
}