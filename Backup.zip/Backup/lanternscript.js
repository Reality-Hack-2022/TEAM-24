// -----JS CODE-----
//@input SceneObject stickyLantern
//@input SceneObject floatingLantern

var slTransform = script.stickyLantern.getTransform();
var flTransform = script.floatingLantern.getTransform();

script.api.repositionLantern = function()
{

    flTransform.setWorldRotation(slTransform.getWorldRotation());
    flTransform.setWorldPosition(slTransform.getWorldPosition());

    print("hello");
};