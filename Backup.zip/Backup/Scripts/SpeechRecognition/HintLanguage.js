// HintLanguage.js
// Event: OnStart
// Version: 0.1.0
// Description: This script update hint language based on VoiceML Language Setting in Speech Recognition Script

// @input Component.ScriptComponent speechRecognition
// @input Component.Text hintText
// @input string hintTextEnglish
// @input string hintTextSpanish
// @input string hintTextGerman

function initialize() {
    if (checkInputValues()) {        
        if (script.speechRecognition.voiceMLLanguage===global.VoiceMLLanguage.LANGUAGE_ENGLISH) {
            script.hintText.text = script.hintTextEnglish;    
        } else if (script.speechRecognition.voiceMLLanguage===global.VoiceMLLanguage.LANGUAGE_SPANISH) {
            script.hintText.text = script.hintTextSpanish; 
        } else if (script.speechRecognition.voiceMLLanguage===global.VoiceMLLanguage.LANGUAGE_GERMAN) {
            script.hintText.text = script.hintTextGerman; 
        }        
    }
}

function checkInputValues() {
    if (script.speechRecognition == null) {
        print("ERROR: Make sure to assign Speech Recognition Script");
        return false;
    } 
    if (script.hintText == null) {
        print("ERROR: Make sure to assign Hint Text Component");
        return false;
    }  

    return true;
}

initialize();